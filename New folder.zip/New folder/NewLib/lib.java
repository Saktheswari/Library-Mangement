import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class lib {
    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/mydb";
    private static final String USER = "root";
    private static final String PASS = "root";

    public static void main(String[] args) {
        Connection conn = null;
        Statement stmt = null;
        
        try {
            // 1. Register JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 2. Open a connection
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            // 3. Execute a query to create a table if not exists
            System.out.println("Creating table in the database...");
            stmt = conn.createStatement();
            String sql = "CREATE TABLE IF NOT EXISTS books " +
                         "(id INT AUTO_INCREMENT PRIMARY KEY, " +
                         " title VARCHAR(255), " +
                         " author VARCHAR(255), " +
                         " quantity INT)";
            stmt.executeUpdate(sql);
            System.out.println("Table created successfully...");

            // 4. Insert a record into the books table
            System.out.println("Inserting records into the table...");
            String insertSQL = "INSERT INTO books (title, author, quantity) VALUES (?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(insertSQL);
            pstmt.setString(1, "The Time Machine");
            pstmt.setString(2, "H.G. Wells");
            pstmt.setInt(3, 1895);
            pstmt.setInt(4, 5);
            pstmt.executeUpdate();
            System.out.println("Record inserted successfully...");

            // 5. Update a record in the books table
            System.out.println("Updating a record in the table...");
            String updateSQL = "UPDATE books SET quantity = ? WHERE title = ?";
            pstmt = conn.prepareStatement(updateSQL);
            pstmt.setInt(1, 10);
            pstmt.setString(2, "The Time Machine");
            pstmt.executeUpdate();
            System.out.println("Record updated successfully...");

            // 6. Retrieve and display records from the books table
            System.out.println("Retrieving records from the table...");
            String selectSQL = "SELECT id, title, author, year, quantity FROM books";
            ResultSet rs = stmt.executeQuery(selectSQL);
            while (rs.next()) {
                // Retrieve data by column name
                int id = rs.getInt("id");
                String title = rs.getString("title");
                String author = rs.getString("author");
                int quantity = rs.getInt("quantity");

                // Display values
                System.out.println("ID: " + id + ", Title: " + title + ", Author: " + author + ", Quantity: " + quantity);
            }
            rs.close();

            // 7. Delete a record from the books table
            System.out.println("Deleting a record from the table...");
            String deleteSQL = "DELETE FROM books WHERE title = ?";
            pstmt = conn.prepareStatement(deleteSQL);
            pstmt.setString(1, "The Time Machine");
            pstmt.executeUpdate();
            System.out.println("Record deleted successfully...");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // 8. Clean-up environment
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        System.out.println("Goodbye!");
    }
}
