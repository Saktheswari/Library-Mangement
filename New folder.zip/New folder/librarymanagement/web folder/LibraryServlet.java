package com.yourpackage;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/submitDetails")
public class LibraryServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        // Get form data from the request
        String title = request.getParameter("title");
        String author = request.getParameter("author");
        // Retrieve more fields as needed

        // Connect to the database and insert data
        try (Connection connection = DatabaseConnection.getConnection()) {
            String sql = "INSERT INTO books (title, author) VALUES (?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, title);
                preparedStatement.setString(2, author);
                // Set more parameters as needed
                preparedStatement.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Redirect or respond to the user
        response.sendRedirect("success.html");
    }
}
