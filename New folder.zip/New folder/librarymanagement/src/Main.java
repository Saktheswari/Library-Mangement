import static spark.Spark.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        port(4567); // Set the port number

        // Route to handle book requests submission
        post("/submitRequest", (req, res) -> {
            String requestId = req.queryParams("id");
            String title = req.queryParams("title");
            String returnDate = req.queryParams("returnDate");
            String status = "Pending";

            // Store the request in the database
            try (Connection connection = DatabaseConnection.getConnection()) {
                String sql = "INSERT INTO borrow_requests (id, title, return_date, status) VALUES (?, ?, ?, ?)";
                try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                    stmt.setString(1, requestId);
                    stmt.setString(2, title);
                    stmt.setString(3, returnDate);
                    stmt.setString(4, status);
                    stmt.executeUpdate();
                }
            } catch (SQLException e) {
                e.printStackTrace();
                return "Error saving request";
            }

            return "Request submitted successfully";
        });

        // Route to fetch requests for the admin page
        get("/getRequests", (req, res) -> {
            StringBuilder response = new StringBuilder();
            try (Connection connection = DatabaseConnection.getConnection()) {
                String sql = "SELECT * FROM borrow_requests WHERE status = 'Pending'";
                try (PreparedStatement stmt = connection.prepareStatement(sql);
                     ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        response.append("<tr>")
                                .append("<td>").append(rs.getString("id")).append("</td>")
                                .append("<td>").append(rs.getString("title")).append("</td>")
                                .append("<td>").append(rs.getString("status")).append("</td>")
                                .append("<td><button onclick=\"updateRequestStatus('").append(rs.getString("id")).append("', 'Approved')\">Approve</button>")
                                .append("<button onclick=\"updateRequestStatus('").append(rs.getString("id")).append("', 'Rejected')\">Reject</button></td>")
                                .append("</tr>");
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
                return "Error fetching requests";
            }
            return response.toString();
        });

        // Route to update the request status
        post("/updateRequestStatus", (req, res) -> {
            String requestId = req.queryParams("id");
            String status = req.queryParams("status");

            // Update the request status in the database
            try (Connection connection = DatabaseConnection.getConnection()) {
                String sql = "UPDATE borrow_requests SET status = ? WHERE id = ?";
                try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                    stmt.setString(1, status);
                    stmt.setString(2, requestId);
                    stmt.executeUpdate();
                }
            } catch (SQLException e) {
                e.printStackTrace();
                return "Error updating request status";
            }

            return "Request status updated successfully";
        });

        // Route to fetch approved/rejected requests for the user's approval page
        get("/getUserRequests", (req, res) -> {
            StringBuilder response = new StringBuilder();
            try (Connection connection = DatabaseConnection.getConnection()) {
                String sql = "SELECT * FROM borrow_requests WHERE status IN ('Approved', 'Rejected')";
                try (PreparedStatement stmt = connection.prepareStatement(sql);
                     ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        response.append("<tr>")
                                .append("<td>").append(rs.getString("id")).append("</td>")
                                .append("<td>").append(rs.getString("title")).append("</td>")
                                .append("<td class=\"text-").append(rs.getString("status").equals("Approved") ? "success" : "danger").append("\">")
                                .append(rs.getString("status")).append("</td>")
                                .append("</tr>");
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
                return "Error fetching user requests";
            }
            return response.toString();
        });
    }
}

