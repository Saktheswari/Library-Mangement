import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;

public class libman{
    public static void main(String[] args) {
        try (Connection connection = library1.getConnection();
             Statement statement = connection.createStatement()) {

            String sql = "SELECT * FROM books";  // Replace 'books' with your table name
            ResultSet resultSet = statement.executeQuery(sql);

            while (resultSet.next()) {
                System.out.println("Title: " + resultSet.getString("title"));
                System.out.println("Author: " + resultSet.getString("author"));
                // Add more fields as necessary
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
